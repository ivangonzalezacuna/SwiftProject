//
//  ViewController.swift
//  CocoaPods - L6
//
//  Created by Iván González Acuña on 02/10/2019.
//  Copyright © 2019 Iván González Acuña. All rights reserved.
//

import UIKit
import SDWebImage
//import Lightbox



class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        sdWebImageExample()
        //lightBoxExample()
        
    }
    
    func sdWebImageExample() {
        imageView.sd_setImage(with: URL(string: "https://image.shutterstock.com/z/stock-photo-mountains-during-sunset-beautiful-natural-landscape-in-the-summer-time-407021107.jpg"))
    }
    
    /*func lightBoxExample() {
        // Create an array of images.
        let images = [
            LightboxImage(imageURL: URL(string: "https://cdn.arstechnica.net/2011/10/05/iphone4s_sample_apple-4e8c706-intro.jpg")!),
            LightboxImage(
                image: UIImage(named: "photo1")!,
                text: "This is an example of a remote image loaded from URL"
            ),
            LightboxImage(
                image: UIImage(named: "photo2")!,
                text: "",
                videoURL: URL(string: "https://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4")
            ),
            LightboxImage(
                image: UIImage(named: "photo3")!,
                text: "This is an example of a local image."
            )
        ]
        
        // Create an instance of LightboxController.
        let controller = LightboxController(images: images)
        
        // Set delegates.
        controller.pageDelegate = self as? LightboxControllerPageDelegate
        controller.dismissalDelegate = self as? LightboxControllerDismissalDelegate
        
        // Use dynamic background.
        controller.dynamicBackground = true
        
        // Present your controller.
        present(controller, animated: true, completion: nil)
        
        

    }*/

}
