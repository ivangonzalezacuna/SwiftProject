//
//  ViewController.swift
//  CocoaPods2 - L6
//
//  Created by Iván González Acuña on 08/10/2019.
//  Copyright © 2019 Iván González Acuña. All rights reserved.
//

import UIKit
import Lightbox

class ViewController: UIViewController {
    
    let images = [
        LightboxImage(imageURL: URL(string: "https://cdn.arstechnica.net/2011/10/05/iphone4s_sample_apple-4e8c706-intro.jpg")!)
    ]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Create an instance of LightboxController.
        let controller = LightboxController(images: images)
        
        // Set delegates.
        //controller.pageDelegate = self as? LightboxControllerPageDelegate
        //controller.dismissalDelegate = self as? LightboxControllerDismissalDelegate
        
        // Use dynamic background.
        controller.dynamicBackground = true
        
        // Present your controller.
        present(controller, animated: true, completion: nil)
        
    }
    
    // MARK: - Action methods
    
    @objc func showLightbox() {
        // Create an array of images.


    }
}
